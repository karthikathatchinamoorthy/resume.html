package ksks;



class BankAccount {
    int accountNumber;
    double balance;
    public BankAccount() {
        accountNumber = 0;   
        balance = 0;         
        System.out.println("✅ Default account created with balance 0");
    }
    public BankAccount(int accNo, double initialBalance) {
        accountNumber = accNo;
        if (initialBalance >= 0) {
            balance = initialBalance;
        } else {
            balance = 0;
            System.out.println(" Invalid initial balance. Set to 0.");
        }
        System.out.println("✅ Account created with given details");
    }
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("💰 Deposited: " + amount);
        } else {
            System.out.println(" Deposit amount must be positive.");
        }
    }
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println(" Withdrawn: " + amount);
        } else {
            System.out.println(" Insufficient balance or invalid amount.");
        }
    }
    public void displayAccount() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }
}
public class cons {
    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount();
        acc1.deposit(500);
        acc1.withdraw(200);
        acc1.displayAccount();
        System.out.println();
        BankAccount acc2 = new BankAccount(12345, 1000);
        acc2.deposit(300);
        acc2.withdraw(1200); // invalid (not enough balance)
        acc2.displayAccount();
    }
}
