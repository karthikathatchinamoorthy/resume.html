package ksks;



class Student {
    
    public String name;        
    private int marks;         
    protected String grade;    
    int rollNumber;            

    
    public Student(String name, int rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
    }

   
    public void setMarks(int marks) {
        if (marks >= 0 && marks <= 100) {
            this.marks = marks;
            calculateGrade(); // internally calculate grade
        } else {
            System.out.println("❌ Invalid marks! Must be between 0 and 100.");
        }
    }

    
    private void calculateGrade() {
        if (marks >= 90) {
            grade = "A";
        } else if (marks >= 75) {
            grade = "B";
        } else if (marks >= 50) {
            grade = "C";
        } else {
            grade = "D";
        }
    }

    public String getGrade() {
        return grade;
    }

    protected void displayBasicInfo() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
    }
}
public class acc{
    public static void main(String[] args) {
        Student s1 = new Student("Vignesh", 101);       
        s1.setMarks(85);
        System.out.println("Grade: " + s1.getGrade());
        s1.displayBasicInfo();
    }
}