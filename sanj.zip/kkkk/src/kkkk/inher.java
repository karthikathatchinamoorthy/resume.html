package kkkk;
class Vehicle {
	 String brand;
	 int speed;
	 public Vehicle(String brand, int speed) {
	     this.brand = brand;
	     this.speed = speed;
	 }
	 public void start() {
	     System.out.println(" Vehicle started");
	 }

	 public void stop() {
	     System.out.println(" Vehicle stopped");
	 }
	}
	class Car extends Vehicle {
	 public Car(String brand, int speed) {
	     super(brand, speed); // Call parent constructor
	 }

	 public void openTrunk() {
	     System.out.println(" Trunk opened");
	 }
	}
	class Bike extends Vehicle {
	 public Bike(String brand, int speed) {
	     super(brand, speed); // Call parent constructor
	 }

	 public void kickStart() {
	     System.out.println(" Bike kick-started");
	 }
	}

	public class inher {
	 public static void main(String[] args) {
	     Car car = new Car("Toyota", 120);
	     System.out.println("Car Brand: " + car.brand + ", Speed: " + car.speed);
	     car.start();
	     car.openTrunk();
	     car.stop();
	     System.out.println();
	     Bike bike = new Bike("Yamaha", 80);
	     System.out.println("Bike Brand: " + bike.brand + ", Speed: " + bike.speed);
	     bike.start();
	     bike.kickStart();
	     bike.stop();
	 }
	}