package kkkk;
class Student {
    String name;
    int rollNumber;
    int marks;
    void setDetails(String name, int rollNumber, int marks) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.marks = marks;
    }
    void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Marks: " + marks);
    }
    boolean isPassed() {
        return marks >= 40;
    }
}

public class std {
    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = new Student();
        Student s3 = new Student();
        s1.setDetails("Alice", 101, 85);
        s2.setDetails("Bob", 102, 35);
        s3.setDetails("Charlie", 103, 55);
        System.out.println("---- Student 1 ----");
        s1.displayDetails();
        System.out.println("Passed: " + s1.isPassed());

        System.out.println("\n---- Student 2 ----");
        s2.displayDetails();
        System.out.println("Passed: " + s2.isPassed());

        System.out.println("\n---- Student 3 ----");
        s3.displayDetails();
        System.out.println("Passed: " + s3.isPassed());
    }
}

