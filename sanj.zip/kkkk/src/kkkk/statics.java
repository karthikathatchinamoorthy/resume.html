package kkkk;



class Employee {
    static String companyName = "Tech Solutions Pvt Ltd";
    static int employeeCount = 0;
    int employeeId;
    String employeeName;
    public Employee(String name) {
        this.employeeName = name;
        employeeCount++; // Increment total employees whenever a new one is created
        this.employeeId = employeeCount; // Assign ID based on count
    }
    public static int getEmployeeCount() {
        return employeeCount;
    }
    public void displayEmployee() {
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Employee Name: " + employeeName);
        System.out.println("Company: " + companyName);
    }
}
public class statics{
    public static void main(String[] args) {
        
        Employee e1 = new Employee("Vignesh");
        Employee e2 = new Employee("Alice");
        Employee e3 = new Employee("Bob");
        e1.displayEmployee();
        System.out.println();
        e2.displayEmployee();
        System.out.println();
        e3.displayEmployee();
        System.out.println("\nTotal Employees: " + Employee.getEmployeeCount());
    }
}