package kkkk;
class BankAccount {
    
    private int accountNumber;
    private double balance;
    public BankAccount(int accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        if (initialBalance >= 0) {
            this.balance = initialBalance;
        } else {
            this.balance = 0;
            System.out.println("❌ Invalid initial balance. Set to 0.");
        }
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("✅ Deposited: " + amount);
        } else {
            System.out.println("❌ Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("✅ Withdrawn: " + amount);
        } else {
            System.out.println("❌ Insufficient balance or invalid amount.");
        }
    }
    public double getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }
}
public class encap {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(12345, 1000);

        
        account.deposit(500);           
        account.withdraw(200);          
        account.withdraw(2000);         
        System.out.println("Account No: " + account.getAccountNumber());
        System.out.println("Current Balance: " + account.getBalance());
    }
}