package kkkk;


class Payment {
	 public void pay(double amount) {
	     System.out.println("💰 Generic payment of " + amount);
	 }
	}
	class CreditCardPayment extends Payment {
	 @Override
	 public void pay(double amount) {
	     System.out.println("💳 Paid " + amount + " using Credit Card");
	 }
	}
	class UPIPayment extends Payment {
	 @Override
	 public void pay(double amount) {
	     System.out.println("Paid " + amount + " using UPI");
	 }
	}
	public class poly{
	public static void main(String[] args) {
	     Payment payment;    
	     payment = new CreditCardPayment();
	     payment.pay(500);
	     payment = new UPIPayment();
	     payment.pay(300);
	     payment = new Payment();
	     payment.pay(100);
	 }
	}
