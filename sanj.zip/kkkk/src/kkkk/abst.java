package kkkk;

public class abst {

}
